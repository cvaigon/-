﻿/*-----------------------------------------------
//////////////// vk.com/d2jscripts //////////////
/////////////////////////////////////////////////
Панель показывает куллдаун скилов и манакост,
так же позволяет сотворить заклинание кликом по иконке
Автор: vk.com/exieros
/////////////////////////////////////////////////
-----------------------End---------------------*/

var Config
try{ Game.Panels.Invokerpanelv2.DeleteAsync(0) }catch(e){}
for (i in Game.Subscribes.Invokerpanelv2)
	try{ GameEvents.Unsubscribe( Game.Subscribes.Invokerpanelv2[i] ) }catch(e){}
Game.Subscribes.Invokerpanelv2 = []
Game.Subscribes.Invokerpanelv2.push( GameEvents.Subscribe('game_newmap', RefreshIPS) )
Game.Subscribes.Invokerpanelv2.push( GameEvents.Subscribe('player_connect_full', RefreshIPS) )
Game.Subscribes.Invokerpanelv2.push( GameEvents.Subscribe('player_connect', RefreshIPS) )
Game.Subscribes.Invokerpanelv2.push( GameEvents.Subscribe('dota_player_pick_hero', RefreshIPS) )
Game.Subscribes.Invokerpanelv2.push( GameEvents.Subscribe('dota_player_update_hero_selection', RefreshIPS) )


function RefreshIPS(){
	var MyID = Game.GetLocalPlayerID()
	try{ Game.Panels.Invokerpanelv2.DeleteAsync(0) }catch(e){}
	for (i in Game.Subscribes.Invokerpanelv2)
		try{ GameEvents.Unsubscribe( Game.Subscribes.Invokerpanelv2[i] ) }catch(e){}
	Game.Subscribes.Invokerpanelv2 = []
}



Invokerpanelv2F = function(){
	var MyID = Game.GetLocalPlayerID()
	if ( MyID==-1 ){
		Invokerpanelv2.checked = false
		try{ Game.Panels.Invokerpanelv2.DeleteAsync(0) }catch(e){}
		for (i in Game.Subscribes.Invokerpanelv2)
			try{ GameEvents.Unsubscribe( Game.Subscribes.Invokerpanelv2[i] ) }catch(e){}
		Game.Subscribes.Invokerpanelv2 = []
		return
	}
	if ( Players.GetPlayerSelectedHero(MyID) != 'npc_dota_hero_invoker' ){
		//Game.ScriptLogMsg('Invokerpanelv2: Not Invoker', '#ff0000')
		Invokerpanelv2.checked = false
		try{ Game.Panels.Invokerpanelv2.DeleteAsync(0) }catch(e){}
		for (i in Game.Subscribes.Invokerpanelv2)
			try{ GameEvents.Unsubscribe( Game.Subscribes.Invokerpanelv2[i] ) }catch(e){}
		Game.Subscribes.Invokerpanelv2 = []
		return
	}
	if (Invokerpanelv2.checked){
		Game.GetFile('Invokerpanelv2/Invokerpanelv2.xml', function(a){
			Game.Panels.Invokerpanelv2 = $.CreatePanel( 'Panel', Game.GetMainHUD(), 'Invokerpanelv2Main' )
			Game.Panels.Invokerpanelv2.BLoadLayoutFromString( a, false, false )
			GameUI.MovePanel(Game.Panels.Invokerpanelv2,function(p){
				var position = p.style.position.split(' ')
				Config.MainPanel.x = position[0]
				Config.MainPanel.y = position[1]
				Game.SaveConfig('Invokerpanelv2/config.conf', Config)
			})
			Game.GetConfig('Invokerpanelv2/config.conf',function(a){
				Config = a[0]
				Game.Panels.Invokerpanelv2.style.position = Config.MainPanel.x + ' ' + Config.MainPanel.y + ' 0'
				Game.Panels.Invokerpanelv2.style.flowChildren = Config.MainPanel.flow
			})
			try{Game.AddCommand( '__Invokerpanelv2_Rotate', function(){
				if (Game.Panels.Invokerpanelv2.Children()[0].style.flowChildren == 'right')
					Game.Panels.Invokerpanelv2.Children()[0].style.flowChildren = 'down'
				else
					Game.Panels.Invokerpanelv2.Children()[0].style.flowChildren = 'right'
				Config.MainPanel.flow = Game.Panels.Invokerpanelv2.style.flowChildren
				Game.SaveConfig('Invokerpanelv2/config.conf', Config)
			}, '',0 )}catch(e){}
		})
		Game.ScriptLogMsg('Script enabled: Invokerpanelv2', '#00ff00')
	}else{
		try{ Game.Panels.Invokerpanelv2.DeleteAsync(0) }catch(e){}
		for (i in Game.Subscribes.Invokerpanelv2)
			try{ GameEvents.Unsubscribe( Game.Subscribes.Invokerpanelv2[i] ) }catch(e){}
		Game.Subscribes.Invokerpanelv2 = []
	}
}
		
var Temp = $.CreatePanel( "Panel", $('#scripts'), "Invokerpanelv2" )
Temp.SetPanelEvent( 'onactivate', Invokerpanelv2F )
Temp.BLoadLayoutFromString( '<root><styles><include src="s2r://panorama/styles/dotastyles.vcss_c" /><include src="s2r://panorama/styles/magadan.vcss_c" /></styles><Panel><ToggleButton class="CheckBox" id="Invokerpanelv2" text="Invokerpanelv2V"/></Panel></root>', false, false)
var Invokerpanelv2 = $.GetContextPanel().FindChildTraverse( 'Invokerpanelv2' ).Children()[0]

RefreshIPS()
